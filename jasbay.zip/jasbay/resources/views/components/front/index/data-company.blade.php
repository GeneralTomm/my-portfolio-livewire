<div>
    <section class="my-20 md:px-0 px-5">
        <div class="max-w-6xl container mx-auto">
            <div class="grid md:grid-cols-2 grid-cols-1">
                <div>
                    <img src="{{asset('gambar1.svg')}}" class="w-full h-64" alt="Jasbay">
                </div>
                <div>
                    <h3 class="text-black font-semibold text-2xl">Jasabay</h3>
                    <p class="text-base font-thin my-4">
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ullam saepe temporibus dolorum nihil at nam asperiores, tenetur similique libero. Doloremque facilis minus optio exercitationem cumque ipsa ut quibusdam tempora omnis.
                    </p>
                    <a href="#" target="_blank" class="text-base px-5 bg-blue-500 py-1 rounded-md text-white mt-4">Kontak Kami</a>
                </div>
            </div>
        </div>
    </section>
</div>
