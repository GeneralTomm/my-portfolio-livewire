<div>
    @include('components.front.portfolio.hero-section')
    @include('components.front.portfolio.filtering-portfolio')
</div>
