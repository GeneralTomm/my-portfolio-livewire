<div>
    @include('components.front.kontak.hero-section')
    @include('components.front.kontak.kontak-kami')
</div>
