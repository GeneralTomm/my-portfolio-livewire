<div>
    @include('components.front.berita.hero-section')
    @include('components.front.berita.filtering-berita')
</div>
