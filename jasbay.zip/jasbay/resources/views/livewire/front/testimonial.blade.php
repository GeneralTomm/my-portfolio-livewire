<div>
    @include('components.front.testimonial.hero-section')
    @include('components.front.testimonial.upload-testimonial')
</div>
