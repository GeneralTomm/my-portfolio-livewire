require('./bootstrap');

import Alpine from 'alpinejs';

var Turbolinks = require("turbolinks")
Turbolinks.start()

window.Alpine = Alpine;

Alpine.start();
