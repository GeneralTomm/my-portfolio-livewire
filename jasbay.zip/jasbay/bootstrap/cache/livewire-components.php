<?php return array (
  'backend.dashboard' => 'App\\Http\\Livewire\\Backend\\Dashboard',
  'backend.data.cara-pemesanan' => 'App\\Http\\Livewire\\Backend\\Data\\CaraPemesanan',
  'backend.fitur-harga-paket' => 'App\\Http\\Livewire\\Backend\\FiturHargaPaket',
  'backend.harga-paket' => 'App\\Http\\Livewire\\Backend\\HargaPaket',
  'backend.keunggulan' => 'App\\Http\\Livewire\\Backend\\Keunggulan',
  'backend.paket' => 'App\\Http\\Livewire\\Backend\\Paket',
  'front.beranda' => 'App\\Http\\Livewire\\Front\\Beranda',
  'front.berita' => 'App\\Http\\Livewire\\Front\\Berita',
  'front.data.data-diri' => 'App\\Http\\Livewire\\Front\\Data\\DataDiri',
  'front.kontak' => 'App\\Http\\Livewire\\Front\\Kontak',
  'front.portfolio' => 'App\\Http\\Livewire\\Front\\Portfolio',
  'front.testimonial' => 'App\\Http\\Livewire\\Front\\Testimonial',
);