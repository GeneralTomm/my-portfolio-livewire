<div>
    <?php echo $__env->make('components.front.berita.hero-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.front.berita.filtering-berita', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH D:\NGODING\Livewire\jasbay\resources\views/livewire/front/berita.blade.php ENDPATH**/ ?>