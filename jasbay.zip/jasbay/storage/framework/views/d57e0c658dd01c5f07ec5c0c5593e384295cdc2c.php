<div>
    <section class="-mt-10 mb-10">
        <div class="max-w-6xl container mx-auto px-5 md:px-0">
            <div class="grid lg:grid-cols-4 md:grid-cols-2 grid-cols-1 gap-4 py-2">
                <?php $__currentLoopData = $dataDiri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white shadow-md p-4 rounded-md hover:-translate-y-4 duration-200">
                        <div class="flex flex-col">
                            <h4 class="text-base font-semibold capitalize"><?php echo e($item['nama_cara']); ?></h4>
                            <p class="text-sm font-light mt-2">
                                <?php echo e($item['deskripsi_cara']); ?>

                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
</div>
<?php /**PATH D:\NGODING\Livewire\jasbay\resources\views/components/front/index/data_diri.blade.php ENDPATH**/ ?>