<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="smooth-scroll select-none">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>
        <link rel="shortcut icon" href="<?php echo e(asset('favicon.svg')); ?>" type="image/x-icon">
        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
         
        <!-- Scripts -->
        
        <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
        <?php echo \Livewire\Livewire::styles(); ?>

    </head>

<body class="font-poppins">

    <?php echo $__env->make('components.backend.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo e($slot); ?>


</body>
<?php echo \Livewire\Livewire::scripts(); ?>

<script src="https://cdn.jsdelivr.net/gh/livewire/turbolinks@v0.1.x/dist/livewire-turbolinks.js" data-turbolinks-eval="false" data-turbo-eval="false"></script>

<script src="<?php echo e(asset('js/flowbite.js')); ?>"></script>

</html>
<?php /**PATH D:\NGODING\Livewire\jasbay\resources\views/layouts/app.blade.php ENDPATH**/ ?>