<footer class="bg-gray-50 p-4 md:px-0 px-4">
    <div class="flex md:flex-row flex-col justify-between items-center max-w-6xl container mx-auto">
        <div>
            <span>
                <a href="#" class="text-sm font-extralight hover:text-blue-800">Kebijakan privasi</a>
            </span>
        </div>
        <div>
            <span class="text-sm font-extralight hover:text-blue-800">All Reserved. 2020 | Jasbay</span>
        </div>
    </div>
</footer>
<?php /**PATH D:\NGODING\Livewire\jasbay\resources\views/components/front/footer.blade.php ENDPATH**/ ?>