<div>
    <section id="hero-section">
        <div class="bg-blue-800 py-32 md:px-0 px-5">
            <div class="max-w-6xl container mx-auto flex flex-col space-y-4 justify-center items-center text-center">
                <h2 class="md:text-4xl text-2xl font-bold text-white">Testimonial Jasbay
                </h2>
            </div>
        </div>
    </section>
</div>
<?php /**PATH D:\NGODING\Livewire\jasbay\resources\views/components/front/testimonial/hero-section.blade.php ENDPATH**/ ?>