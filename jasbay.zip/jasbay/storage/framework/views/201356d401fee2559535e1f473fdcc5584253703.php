<div>
    <?php echo $__env->make('components.front.testimonial.hero-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.front.testimonial.upload-testimonial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH D:\NGODING\Livewire\jasbay\resources\views/livewire/front/testimonial.blade.php ENDPATH**/ ?>