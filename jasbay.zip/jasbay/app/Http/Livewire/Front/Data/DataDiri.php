<?php

namespace App\Http\Livewire\Front\Data;

use Livewire\Component;

class DataDiri extends Component
{
    public function render()
    {
        return view('livewire.front.data.data-diri');
    }
}
